# Codeanix

Static marketing site for Codeanix — AI automation, workflow, and growth services.

## Structure

```
index.html      Main page (nav, hero, services, pricing, footer)
css/style.css   All styles — dark theme, gradients, responsive breakpoints
js/main.js      Mobile nav, scroll reveal, animated stat counters, canvas particle backgrounds
vercel.json     Deployment config (clean URLs, cache headers, security headers)
```

No build step, no dependencies, no package.json required — plain HTML/CSS/JS.

## Deploy to Vercel (via GitHub)

1. Push this folder to a new GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Framework preset: **Other** (or "Static"). Leave build command and output directory blank — Vercel will serve the root as-is.
4. Deploy. Done — no environment variables or config needed.

## Local preview

Any static server works, e.g.:
```bash
python3 -m http.server 8000
```
Then open `http://localhost:8000`.

## Custom domain

Once deployed, add `codeanix.com` under the Vercel project's **Settings → Domains**, and point your domain's DNS (A/CNAME records, per Vercel's instructions) at Vercel.
