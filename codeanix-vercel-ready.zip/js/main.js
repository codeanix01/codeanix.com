(() => {
  'use strict';

  /* ---------------------------------------------------------
     Mobile nav toggle
  --------------------------------------------------------- */
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');

  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      const isOpen = mobileMenu.classList.toggle('is-open');
      hamburger.classList.toggle('is-active', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    mobileMenu.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        mobileMenu.classList.remove('is-open');
        hamburger.classList.remove('is-active');
        document.body.style.overflow = '';
      });
    });
  }

  /* ---------------------------------------------------------
     Scroll reveal (IntersectionObserver)
  --------------------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -60px 0px' }
    );
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* ---------------------------------------------------------
     Animated stat counters
  --------------------------------------------------------- */
  const statEls = document.querySelectorAll('.stat__value[data-count]');
  const animateCount = (el) => {
    const target = parseFloat(el.getAttribute('data-count'));
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 1400;
    const start = performance.now();
    const inner = el.querySelector('span');

    const step = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = Math.floor(eased * target);
      el.firstChild.textContent = value;
      if (inner) el.appendChild(inner);
      if (progress < 1) requestAnimationFrame(step);
      else {
        el.firstChild.textContent = target;
      }
    };
    requestAnimationFrame(step);
  };

  if ('IntersectionObserver' in window && statEls.length) {
    const statIO = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCount(entry.target);
            statIO.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.4 }
    );
    statEls.forEach((el) => statIO.observe(el));
  }

  /* ---------------------------------------------------------
     Lightweight canvas particle backgrounds
     (dependency-free replacement for a Three.js scene —
     keeps the visual without requiring an external library)
  --------------------------------------------------------- */
  function initParticleCanvas(canvas, options = {}) {
    if (!canvas || !canvas.getContext) return;
    const ctx = canvas.getContext('2d');
    const density = options.density || 70;
    const color = options.color || '124, 92, 255';
    const linkDistance = options.linkDistance || 130;
    const speed = options.speed || 0.25;

    let particles = [];
    let width, height, dpr;
    let animId;

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.parentElement.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = width + 'px';
      canvas.style.height = height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
    }

    function seed() {
      const count = Math.max(18, Math.round((width * height) / (10000 * (100 / density))));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * speed,
        vy: (Math.random() - 0.5) * speed,
        r: Math.random() * 1.6 + 0.6,
      }));
    }

    function tick() {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;
      });

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const a = particles[i];
          const b = particles[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < linkDistance) {
            ctx.strokeStyle = `rgba(${color}, ${0.16 * (1 - dist / linkDistance)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      particles.forEach((p) => {
        ctx.fillStyle = `rgba(${color}, 0.8)`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(tick);
    }

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    resize();
    window.addEventListener('resize', resize);

    if (!prefersReducedMotion) {
      tick();
    } else {
      // Draw a single static frame instead of animating
      particles.forEach((p) => {
        ctx.fillStyle = `rgba(${color}, 0.6)`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Pause when tab is hidden to save battery/CPU
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        cancelAnimationFrame(animId);
      } else if (!prefersReducedMotion) {
        tick();
      }
    });
  }

  initParticleCanvas(document.getElementById('hero-canvas'), {
    density: 70,
    color: '124, 92, 255',
    linkDistance: 140,
    speed: 0.22,
  });

  initParticleCanvas(document.getElementById('about-canvas'), {
    density: 45,
    color: '56, 208, 216',
    linkDistance: 110,
    speed: 0.18,
  });

  initParticleCanvas(document.getElementById('shapes-canvas'), {
    density: 40,
    color: '124, 92, 255',
    linkDistance: 100,
    speed: 0.3,
  });

  /* ---------------------------------------------------------
     Sticky nav background intensifies on scroll
  --------------------------------------------------------- */
  const navEl = document.getElementById('main-nav');
  if (navEl) {
    const onScroll = () => {
      navEl.style.background = window.scrollY > 40
        ? 'rgba(5, 5, 8, 0.92)'
        : 'rgba(5, 5, 8, 0.75)';
    };
    document.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
})();
